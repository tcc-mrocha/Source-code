Some osciloscope images...

- 01 - Trigger signal from NodeMCU before and after logic level converter
- 02 - Echo signal from HC-SR04 before and after logic level converter
- 03 - Trigger and echo at 5V, near an obstacle
- 04 - Trigger and echo at 5V, far from an obstacle
- 05 - Trigger and echo at 3.3V, near an obstacle
- 06 - Trigger and echo at 3.3V, far from an obstacle
